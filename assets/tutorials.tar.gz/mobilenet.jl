using Pkg # hideall
Pkg.activate("./Project.toml")
Pkg.instantiate()

# This file was generated using Literate.jl, https://github.com/fredrikekre/Literate.jl
