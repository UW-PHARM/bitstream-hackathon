using Pkg # hideall
Pkg.activate("./Project.toml")
Pkg.instantiate()

Pkg.activate(".") # hideall

# This file was generated using Literate.jl, https://github.com/fredrikekre/Literate.jl
